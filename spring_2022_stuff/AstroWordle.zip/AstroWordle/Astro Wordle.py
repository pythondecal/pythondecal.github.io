import random
import pygame
from pygame.locals import *
import pandas as pd

pygame.init()

# WORD LIST
word_list = pd.read_csv('termstable.csv')

random_int = random.randint(0, len(word_list) - 1)


def get_word():
    return word_list.iloc[random_int, 1]


def is_word(guess):
    if guess in word_list:
        return True


def print_guess(guess, letters, available):
    out = ''
    for j in range(len(letters)):
        letter = guess[j]
        if letter == letters[j]:
            pygame.draw.rect(Surface, green,
                             (78 + j * 80 + j, 53 + guess_number * 80, 69, 69))
            pygame.display.flip()
            out += f'{letter} '
            if letter in available:
                available[available.index(letter)] = letter.upper()
        elif letter in letters:
            pygame.draw.rect(Surface, yellow,
                             (78 + j * 80 + j, 53 + guess_number * 80, 69, 69))
            pygame.display.flip()
            out += f'{letter}* '
        else:
            out += 'X '
            if letter in available:
                available.remove(letter)
    return available


available = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
             'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


def checker(guess):
    global input_rect
    global guess_number
    global user_text
    global word_to_guess
    global game_end
    guess = guess.lower()
    if guess_number < 6:
        if guess_number == 3:
            print(word_list.iloc[random_int, 2])
        if len(guess) != len(word_to_guess):
            print(f'Word must be of length {len(word_to_guess)}.')
        elif not guess.isalpha():
            print('Word must be letters only.')
        elif guess == word_to_guess:
            game_end = True
            print(print_guess(guess, word_to_guess, available))
            print("You found the Astro Wordle!")
        else:
            print(print_guess(guess, word_to_guess, available))
            guess_number += 1
            for x in range(7):
                if guess_number == x:
                    past_user_guesses[f"user_text{x}"] = user_text
            if guess_number < 6:
                user_text = ''
    else:
        print("You lost! Try again!")
        game_end = True


running = True
word_to_guess = get_word()
guess_number = 0
number_of_letters = len(word_to_guess) #max 16 letters long
width, height = number_of_letters*80+145, 1000
Surface = pygame.display.set_mode((width, height))
pygame.display.set_caption('Astro Wordle')
font = pygame.font.Font('CourierPrime-Bold.ttf', 45)
input_rect = pygame.Rect(96, 65, 75, 75)
clock = pygame.time.Clock()
past_user_guesses = {}
user_text = ''
yellow = (255, 191, 0)
green = (80, 200, 120)
game_end = False

while running:
    for event in pygame.event.get():
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                running = False
        if event.type == QUIT:
            running = False
        if game_end:
            running = False
        if event.type == pygame.KEYDOWN:
            # Check for backspace
            if event.key == pygame.K_BACKSPACE:
                pygame.draw.rect(Surface, (20, 20, 20),
                                 (78 + (len(user_text.replace(" ", ""))-1) * 80 + len(user_text.replace(" ", ""))-1,
                                  53 + guess_number * 80, 69, 69))
                # get text input from 0 to -3 i.e. end.
                user_text = user_text[:-3]
            elif event.key == pygame.K_RETURN and guess_number <= 6:
                checker(user_text.replace(" ", ""))
            # Unicode standard is used for string
            # formation
            else:
                if len(user_text) > (number_of_letters - 1) * 3:
                    continue
                user_text += event.unicode
                user_text += "  "
    if guess_number == 0:
        # color of the page
        Surface.fill((20, 20, 20))
        # making background squares
        for change_y in range(6):
            for change_x in range(number_of_letters):
                pygame.draw.rect(Surface, (88, 88, 88), (75 + change_x * 80 + change_x, 50 + change_y * 80, 75, 75))
                pygame.draw.rect(Surface, (20, 20, 20), (78 + change_x * 80 + change_x, 53 + change_y * 80, 69, 69))
    # rendering text
    text_surface = font.render(user_text, True, (255, 255, 255))
    for i in range(6):
        if guess_number == i:
            Surface.blit(text_surface, (input_rect.x, input_rect.y + i * 80))
    # probably super cringe way of keeping track of past attempts
    if guess_number >= 1:
        text_surface1 = font.render(past_user_guesses["user_text1"], True, (255, 255, 255))
        Surface.blit(text_surface1, (input_rect.x, input_rect.y))
    if guess_number >= 2:
        text_surface2 = font.render(past_user_guesses["user_text2"], True, (255, 255, 255))
        Surface.blit(text_surface2, (input_rect.x, input_rect.y+1*80))
    if guess_number >= 3:
        text_surface3 = font.render(past_user_guesses["user_text3"], True, (255, 255, 255))
        Surface.blit(text_surface3, (input_rect.x, input_rect.y+2*80))
    if guess_number >= 4:
        text_surface4 = font.render(past_user_guesses["user_text4"], True, (255, 255, 255))
        Surface.blit(text_surface4, (input_rect.x, input_rect.y+3*80))
    if guess_number >= 5:
        text_surface5 = font.render(past_user_guesses["user_text5"], True, (255, 255, 255))
        Surface.blit(text_surface5, (input_rect.x, input_rect.y+4*80))
    if guess_number >= 6:
        text_surface6 = font.render(past_user_guesses["user_text6"], True, (255, 255, 255))
        Surface.blit(text_surface6, (input_rect.x, input_rect.y+5*80))

    # ending code bit
    pygame.display.flip()
    pygame.event.pump()
    clock.tick(60)
pygame.quit()
