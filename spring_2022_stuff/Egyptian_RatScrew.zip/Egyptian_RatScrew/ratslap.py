
### Code Preamble ###
import random
import numpy as np
import time

from functools import total_ordering
from random import shuffle



## DEFINE CLASSES ##
# card, deck, and hand classes

            ##########################################################################################                          OOP for Cards
##########################################################################################

# class to hold information for playing cards
@total_ordering
class Card():
  # attributes of Card
  # Suit: int; an integer from 0-3 indicating clubs, diamonds, hearts, or spades
  # Rank: int; an integer from 0-13 (0 indicates none)
  

  suits = ['♦', '♣', '♥', '♠']
  ranks = [
      None, "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"
  ]

  def __init__(self, suit=0, rank=0):
    # initialize Card with suit and rank
    self.suit = suit
    self.rank = rank

  def __eq__(self, other):
    # checks if equal to other card
    return ((self.suit, self.rank) == (other.suit, other.rank))

  def __ne__(self, other):
    # checks if not equal to other card
    return not (self == other)

  def __lt__(self, other):
    # checks value of self compared to other card
    return ((self.suit, self.rank) < (other.suit, other.rank))

  def __repr__(self):
    # wordle representation of card
    return "{}({} {})".format(self.__class__.__name__, self.suit, self.rank)

  def __str__(self):
    # make the card a string
    return '|{:^2}{}|'.format(self.ranks[self.rank], self.suits[self.suit])
    

  def value_ERS(self):
    # ers value of card (for face cards)
    if self.rank == 11:
      return 1
    elif self.rank == 12:
      return 2
    elif self.rank == 13:
      return 3
    elif self.rank == 1:
      return 4
    else:
      return 0

  def is_face(self):
    # checks if card is a face card
    if 11 <= self.rank <= 13 or self.rank == 1:
      return True
    else:
      return False


# make a stack of cards
class CardStack():
  # class attributes
  # stack: list; list of cards in deck
  # size: int; number of cards in deck, starts at zero

  def __init__(self):
    # initialize an empty stack of cards

    self.stack = []
    self.size = 0

  def __repr__(self):
    # represent stack
    return "{} [{}]".format(self.__class__.__name__, ", ".join(
        repr(c) for c in self.stack))

  def __str__(self):
    # represent stack as a string

    if self.size > 13:
      # If longer than 13, print shortened version with elipses
      return "  ... {}".format(" ".join(str(c) for c in self.stack[-9:]))
    else:
      # Otherwise print 10 cards
      return "{}".format(" ".join(str(c) for c in self.stack))

  def is_empty(self):
    # checks if card stack is empty
    # returns a boolean
    # True if cardstack is empty; False if not

    return self.size == 0

  def pop(self, i=-1):
    # pop the i-th card off the top of the deck
    if not self.is_empty():
 
      temp = self.stack
      removed = temp.pop(i)

      self.stack = temp
      self.size -= 1

      return removed
    else:
      raise IndexError("Cannot perform operation on empty %s.",
                       self.__class__.__name__)

  def peek(self):
    #look at card at top of stack
    return self.stack[-1]

  def append(self, card):
    #add card to the top of the stack
    self.stack += [card]
    self.size += 1

  def prepend(self, card):
    #add card to the front of the stack

    self.stack = [card] + self.stack
    self.size += 1

# use the previous class to make a whole (proper) deck of cards
class Deck(CardStack):
  
  # attributes
  # stack: list; list of cards in deck
  # size: int; number of cards in deck

  def __init__(self):
    # initialize a stack of 52 cards (ie a standard deck)
    super().__init__()
    self.size = 52

    for suit in range(4):
      for rank in range(1, 14):
        card = Card(suit, rank)
        self.stack.append(card)

  def shuffle(self):
    # shuffle deck using random package
    shuffle(self.stack)

  def to_hand(self, player, num, toTop=False):
    # move num cards from deck to bottom of players hand
    # parameters
    # player: Player; player to give cards to
    # num: int; number of cards to move to hand
    # toTop: bool; indicates if cards should be added to the top or bottom of players     # hand
    # default is false, thus cards will automatically be moved to the bottom of the       # players hand

    if not self.is_empty():
      if toTop:
        for i in range(num):
          # print(self)
          player.hand.append(self.pop())
      else:
        for i in range(num):
          # print(self.size)
          player.hand.prepend(self.pop())
    else:
      raise IndexError(
          "Cannot perform operation on empty %s." % self.__class__.__name__)


class Hand(CardStack):
  # the players hand. cards will be face down
  # attributes
  # stack: list; list of cards in players hand
  # size: int; number of cards in players hand

  def __init__(self):
    # initialize an empty hand

    super().__init__()

  def to_deck(self, deck, num, toTop=True):
    # Move top `num` Cards from Hand to top/bottom of Deck
    # paramters
    # deck: Deck; deck to add cards to
    # num: int; number of cards to move to deck
    # toTop: bool; indicates if cards from hand should be moved to the top or the         # bottom of deck
    # the default is true (which is the top of the deck)

    if not self.is_empty():
      if toTop:
        for i in range(num):
          deck.append(self.pop())
      else:
        for i in range(num):
          deck.prepend(self.pop())
    else:
      raise IndexError(
          "Cannot perform operation on empty %s." % self.__class__.__name__)

##########################################################################################                          
#                                    OOP for Player                                      #
##########################################################################################
#!/usr/bin/env python



class Player:
  # attributes
  # num_cards: int; the number of cards a player has
  # id: str; a player's id

  def __init__(self, id=''):
    # initialize player

    self.hand = Hand()
    self.id = id
    self.turnsLeft = 0
    self.hasToBeat = False
    

  def __repr__(self):
    # string representation of card
    return "%s(%s)" % (self.__class__.__name__, repr(self.hand))

  def __str__(self):
    # stringify
    return "%s" % (str(self.hand))
 

  def spit(self, deck):
    # player moves top card from card stack to top of deck (face up)
    # parameters
    # deck: Deck; the main deck to move card to
    temp = self.hand.peek()
    self.hand.to_deck(deck, 1, toTop=True)
    print_player("+ %s" % (temp), self, replace=True)

  def burn(self, deck):
    # player moves top card from card stack to bottom of deck (face up)
    # parameters
    # deck: Deck; the main deck that the player slapped
    self.hand.to_deck(deck, 1, toTop=False)

  def slap(self, deck):
    # the player slaps the main deck. If the slap is good,
    # the entire deck is transferred to the players hand
    # if not, the player must burn one card.
    print_player("slapped the deck", self)

    slapRule = self._check_slap(deck)
    if (slapRule is not False):
      # Good slap -> move all deck cards to hand
      whoWon = "You" if self.id == 0 else "Player %d" % (self.id)
      print_player(
          "+ %d cards. %s won the deck with the %s!" % (deck.size, whoWon,
                                                             slapRule), self)
      deck.to_hand(self, deck.size, toTop=False)
      return True

    else:
      # Bad slap -> burn one card to front of deck
      temp = self.hand.peek()
      self.burn(deck)
      print_player("- %s Bad slap!" % (temp), self)
      return False

  @staticmethod
  def _check_slap(deck):
    # Check if deck is slappable 
    ## RULES: ##
    # Double – When two cards of equivalent value are laid down consecutively. 
    # Sandwich – When two cards of equivalent value are laid down consecutively, but with one card of different value between them. 


    slapIsGood = False
    slapRule = None
    slapLogFormat = "{} Rule"

    def deck1(_deck):
      # if deck is just 1 card
      # can't slap
      return []  # don't implement Joker card

    def deck2(_deck):
      # if deck is 2 cards
      # can slap if:
      # doubles
      # top-bottom sandwich (basically the same thing as doubles if only two cards)
      # tens (add up to tens)
      # marriage (king and queen consecutively)

      if _deck.stack[-1].rank == _deck.stack[-2].rank:
        return [slapLogFormat.format("Double")]
      if _deck.stack[-1].rank == _deck.stack[0].rank:
        return [slapLogFormat.format("Top Bottom")]
      if _deck.stack[-1].rank + _deck.stack[-2].rank == 10:
        return [slapLogFormat.format("Tens - 2 cards")]
      if (_deck.stack[-1].rank == 12 and _deck.stack[-2].rank == 13) or \
              (_deck.stack[-1].rank == 13 and _deck.stack[-2].rank == 12):
        return [slapLogFormat.format("Marriage")]
      return []

    def deck3(_deck):
      # if deck is 3 cards
      # can slap if:
      # sandwich (card in between two cards with same value)

      if _deck.stack[-1].rank == _deck.stack[-3].rank:
        return [slapLogFormat.format("Sandwich")]
      if 11 <= _deck.stack[-2].rank <= 13 and sum(
          [e.rank for e in _deck.stack[-3:]]) == 10:
        return [slapLogFormat.format("Tens - 3 cards")]
      return []

    def deck4(_deck):
      # if deck is 4 cards

      if all(diff == 1 for diff in [y.rank - x.rank for x, y in zip(_deck.stack[-4:-1], _deck.stack[-3:])]):
            
         return [slapLogFormat.format("Four in a row")]
      return []

    if deck.size == 1:
      slapRule = deck1(deck)

    elif deck.size == 2:
      slapRule = deck1(deck) + deck2(deck)

    elif deck.size == 3:
      slapRule = deck1(deck) + deck2(deck) + deck3(deck)

    elif deck.size >= 4:
      slapRule = deck1(deck) + deck2(deck) + deck3(deck) + deck4(deck)

    else:
      slapRule = []

    if len(slapRule) == 0:
      return False
    else:
      return slapRule[0]


class User(Player):
    # initialize user object
  def __init__(self, id='0'):
    super().__init__(id)


class Computer(Player):
    
  def __init__(self, id=''):
   # initialize computer object

    super().__init__(id)

    self.hand = Hand()
    self.seed = random.seed()
    
    self.errorSlapRate = 0.25  

  def spit(self, deck):
    # inherit spit with a random delay
    # parameters
    # deck: Deck; the main deck to move card to
    spitTime = random.uniform(1, 2)
    time.sleep(spitTime)
    super().spit(deck)

  def slap(self, deck):
    # inherit slap with random delay and random error
    # parameters: 
    # deck: Deck; the main deck to move card to

    if random.random() < self.errorSlapRate:
      slapTime = random.uniform(1, 5) # make it easier on the player lmao 
      time.sleep(slapTime)
      super().slap(deck)  


##########################################################################################
#                                 Printer Info                                           #
##########################################################################################

logWidth = 13

def print_info(message):
  print("> [INFO".ljust(logWidth) + "]: " + str(message))


def print_player(message, player, replace=False):
  concatP = "Player %d (%d)" % (player.id, player.hand.size)
  print(concatP.ljust(logWidth) + " " + str(message))


def print_deck(message):
  print("Deck".ljust(logWidth) + " > " + str(message))


def print_slaprule(message):
  print("Slap Rule".ljust(logWidth) + " > " + str(message))


def print_scoreboard(game):
  #Prints scores (# of cards) of each player
  scores = "; ".join(("Player " + str(i) + ": " + str(p.hand.size)) for i,p in enumerate(game.players))
  print(scores)


# DEBUG
def print_turns(game):
  x = "; ".join(("P" + str(i) + ": " + ("Yes" if (not q.empty()) else "No"))
                for i, q in enumerate(game.turns))
  x = "Whose turn - " + x
  print(x)


def print_turnsLeft(game):
  x = "; ".join(("P" + str(i) + ": " + str(p.turnsLeft))
                for i, p in enumerate(game.players))
  x = "Turns left - " + x
  print(x)

##########################################################################################
#                                 Event Managing                                         #
##########################################################################################

import multiprocessing
import inspect
from multiprocessing.managers import BaseManager, NamespaceProxy, AutoProxy


# ======= Workaround for py36 bug ========

# https://stackoverflow.com/questions/46779860/multiprocessing-managers-and-custom-classes

# Backup original AutoProxy function
backup_autoproxy = multiprocessing.managers.AutoProxy

# Defining a new AutoProxy that handles unwanted key argument 'manager_owned'


def redefined_autoproxy(token,
                        serializer,
                        manager=None,
                        authkey=None,
                        exposed=None,
                        incref=True,
                        manager_owned=True):
  # Calling original AutoProxy without the unwanted key argument
  return backup_autoproxy(token, serializer, manager, authkey, exposed, incref)


# Updating AutoProxy definition in multiprocessing.managers package
AutoProxy = redefined_autoproxy

# ========================================


class GameManager(BaseManager):
  pass


# A proxy that exposes all class methods AND attributes


class NamedProxy(NamespaceProxy):
  _exposed_ = ('__getattribute__', '__setattr__', '__delattr__')


def register_proxy(name, cls, proxy):
  for attr in dir(cls):
    if inspect.ismethod(getattr(cls, attr)) and not attr.startswith("__"):
      proxy._exposed_ += (attr,)
      setattr(proxy, attr,
              lambda s: object.__getattribute__(s, '_callmethod')(attr))
  GameManager.register(name, cls, proxy)


register_proxy('CardStack', CardStack, NamedProxy)
register_proxy('Deck', Deck, NamedProxy)
register_proxy('Hand', Hand, NamedProxy)
register_proxy('User', User, NamedProxy)
register_proxy('Computer', Computer, NamedProxy)

##########################################################################################
#                               Game Logic / Class
##########################################################################################


#######################################################################################################################

import ctypes

# from multiprocessing import Process, Condition, Lock, Queue
from threading import Lock, Thread, Event, Timer
import queue
import time

class ERS:

  def __init__(self, numOfPlayers):

    self.numOfPlayers = numOfPlayers
    self.numOfCardsPerPlayer = 52 // numOfPlayers
    self.players = []
    self.turns = [queue.Queue(maxsize=1) for _ in range(numOfPlayers)]
    
    # tbh not sure what this is for but its defo useful
    self.lock = Lock() 
    self.threads = []

  def __str__(self):
    scores = "; ".join(("Player " + str(i) + ": " + str(p.hand.size))
                       for i, p in enumerate(self.players))
    return scores

  def start_game(self):

    print_info("Game started!")

    # Initialize Deck
    deck = Deck()
    deck.shuffle()

    # Initialize all players
    print_info("Dealing {} cards each to {} players".format(
        self.numOfCardsPerPlayer, self.numOfPlayers))

    # Initialize player 0 
    user_id = 0
    playerProcess = Thread(target=self.player_process, args=(user_id, deck))

    self.threads.append(playerProcess)

    for cpu_id in range(1, self.numOfPlayers):

      # CPU Processes
      cpuProcess = Thread(target=self.cpu_process, args=(cpu_id, deck))
      self.threads.append(cpuProcess)
    for thread in self.threads:
      thread.start()
    
    self.turns[0].put(1)

  def controller(self, deck):
    pass

  def player_process(self, id, deck):

    me = User(id)

    myQueue = self.turns[id]
    nextQueue = self.turns[(id + 1) % self.numOfPlayers]

    self.players.append(me)
    deck.to_hand(me, self.numOfCardsPerPlayer)
    me.turnsLeft = 1

    while True:

      # If player's turn
      if not myQueue.empty():

        # Implement game logic here

        if me.turnsLeft > 0:
          # if there are still turns left, don't change turns

          response = input("> ")  

          if response == "d": #d for draw
            # spit
            self.game_logic(me, id, deck)

          elif response == "s": #s for slap
            # slap
            me.slap(deck)
          
          elif response == "x":
            # print deck
            print_deck(deck)

        elif me.turnsLeft == 0:
          # if there are no turns left, change turns
          self.change_turns(nextQueue)

      # Even if not player's turn, ask for response; only choice is slap
      else:
        pass

  def cpu_process(self, id, deck):

    cpu = Computer(id)
    myQueue = self.turns[id]
    nextQueue = self.turns[(id + 1) % self.numOfPlayers]

    self.players.append(cpu)
    deck.to_hand(cpu, self.numOfCardsPerPlayer)

    while True:

      if not myQueue.empty():
        # If player's turn

        # Implement game logic here

        # Still check if cpu can slap
        if cpu._check_slap(deck) is not False:
          cpu.slap(deck)

        # Spit accordingly

        if cpu.turnsLeft > 0:    
          self.game_logic(cpu, id, deck)

        elif cpu.turnsLeft == 0:
          # if there are no turns left, change turns
          self.change_turns(nextQueue)

      else:
        # Still check if cpu can slap
        if cpu._check_slap(deck) is not False:
          print_deck(deck)
          cpu.slap(deck)

  def game_logic(self, me, id, deck):

    # spit
    me.spit(deck)
    me.turnsLeft -= 1
    nextPlayer = self.players[(id + 1) % self.numOfPlayers]
    prevPlayer = self.players[(id - 1) % self.numOfPlayers]

    value_of_last_card = deck.peek().value_ERS()

    if value_of_last_card > 0:
      # If the card just placed down is special, go to next player
      me.turnsLeft = 0
      nextPlayer.turnsLeft = value_of_last_card
      nextPlayer.hasToBeat = True
    elif me.turnsLeft == 0:
      # If last card was placed down, check if go to next player
      if value_of_last_card == 0 and me.hasToBeat:
        # If value of last card is 0 and player had to beat other player's face card but lost, then previous player takes deck
        whoWon = "You" if prevPlayer.id == 0 else "Player %d" % (prevPlayer.id)
        print_player("+ %d cards. %s won the deck!" % (deck.size, whoWon),
                     prevPlayer)
        deck.to_hand(prevPlayer, deck.size)
        prevPlayer.turnsLeft = 1
      elif value_of_last_card == 0 and not me.hasToBeat:
        # If value of last card is 0 and player didn't have to beat other player's face card, then play continues
        nextPlayer.turnsLeft = 1
      me.turnsLeft = 0
      me.hasToBeat = False
      nextPlayer.hasToBeat = False

  def change_turns(self, queue):

    for q in self.turns:
      with q.mutex:
        q.queue.clear()
    queue.put(1)


  def winner_exists(self):
    # checks if a winner exists for this round

    playersWithCards = [
        i for i, player in enumerate(self.players) if not player.hand.size == 0]
    if len(playersWithCards) == 1:
      return True
    else:
      return False

##########################################################################################
#### play game here ####
##########################################################################################


splash = """
  _                                     _                __                   
 |_   _       ._   _|_  o   _.  ._     |_)   _.  _|_    (_    _  ._   _       
 |_  (_|  \/  |_)   |_  |  (_|  | |    | \  (_|   |_    __)  (_  |   (/_  \/\/
      _|  /   |                                                               
-------------------------------------------------------------------------------
"""
rules = """

* Double\t\tWhen two cards of equivalent value are laid down consecutively. Ex: 5, 5
* Sandwich\tWhen two cards of equivalent value are laid down consecutively, but with one card of different value between them. Ex: 5, 7, 5
* press d to draw a card
* press s to slap a card
* press x to print the deck 
"""

def main():

  numOfPlayers = 2

  game = ERS(numOfPlayers)

  print(splash + rules)
  game.start_game()

if __name__ == '__main__':
    main()








