#!/usr/bin/env python
# coding: utf-8

# In[15]:


import numpy as np
import matplotlib.pyplot as plt

def magnification(u):
    return np.abs((u**2 + 2)/ (u * np.sqrt(u**2 + 4)))

x = np.linspace(-2, 2, 1000)

y = magnification(x)

plt.plot(x,y)


# In[16]:


import numpy as np
import matplotlib.pyplot as plt

def magnification(u):
    return ((u**2 + 2)/ (u * np.sqrt(u**2 + 4)))

x = np.logspace(-2, 1,100)

y = magnification(x)

plt.loglog(x,y)


# In[73]:


import numpy as np
import matplotlib.pyplot as plt

fig = plt.figure(figsize=(12, 9))

def magnification1(u):
    return 2*np.e**(-u**2)

x = np.linspace(-4, 4)

y1 = magnification1(x)

plt.plot(x,y1,color='red',label='4 Solar Masses')

def magnification3(u):
    return 1.5*np.e**(-u**2/2)

y3 = magnification3(x)

plt.plot(x,y3,color='orange',label='2 Solar Masses')

def magnification5(u):
    return np.e**(-u**2/4)

y5 = magnification5(x)

plt.plot(x,y5,color='green',label='1 Solar Mass')

def magnification2(u):
    return 0.75*np.e**(-u**2/8)

y2 = magnification2(x)

plt.plot(x,y2,color='blue',label='1/2 Solar Mass')

def magnification4(u):
    return 0.5*np.e**(-u**2/16)

y4 = magnification4(x)

plt.ylabel('Magnification')
plt.plot(x,y4,color='purple',label='1/4 Solar Mass')
plt.title('Magnification of Lens Based on Mass')
plt.legend()


# In[ ]:





# $$\mu_\pm = \frac{u^2+2}{2u\sqrt{u^4+4}} \pm \frac{1}{2}$$

# $$\mu = \frac{u^2+2}{u\sqrt{u^2+2}}$$

# In[ ]:




