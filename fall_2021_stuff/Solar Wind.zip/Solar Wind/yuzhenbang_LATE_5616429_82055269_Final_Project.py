import numpy as np
import matplotlib.pyplot as plt
import scipy
import scipy.integrate   #Solving ODE

from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FFMpegWriter

# Define masses

#mp = 5.9722e24  # Earth: me = 5.9722 × 10^24 kilograms
#ms = 1.989e30   # Sun(Star): ms = 1.989 × 10^30 kg

mp = 3 * 10**(-5)
ms = 1

# Define initial position vectors 
#r1 = np.array([1.5e11, 0]) # location of the planet
r1 = np.array([1, 0])
#Initial distance (average): r_i = 1.5 × 10^11 m
r2 = np.array([0, 0]) # at orgin

# Define initial velocities
#v1 = np.array([0, 29720]) # velocity of the planet
v1 = np.array([0, 1])
# V_e = 107,000 km/h = 29720m/s
v2 = np.array([0, 0]) # stationary

def OrbitEquation(w, t, mp, ms): # w is an array containing positions and velocities
    r1 = w[:2]
    v1 = w[2:4]
    
    r12 = np.linalg.norm(r1)
    m_t = ms*(1-10**(-13))**(t*np.pi*1e10) #t=10000year
    #ms(t) = ms(1-10^(-13))^t
    dv1bydt = m_t*(-r1)/r12**3  # derivative of velocity

    dr1bydt = v1 # derivative of position 
    
    r_derivs = dr1bydt
    v_derivs = dv1bydt
    derivs = np.concatenate((r_derivs, v_derivs)) # joining the two arrays
    
    return derivs

# Package initial parameters into one array (just easier to work with this way)
init_params = np.array([r1, v1])
init_params = init_params.flatten()
time_span = np.linspace(0, 50, 500)  # run for t=5 (500 points)

# Run the ODE solver
sol = scipy.integrate.odeint(OrbitEquation, init_params, time_span, args=(mp,ms))
r1_sol = sol[:,:2]

# Initilize writer 
metadata = dict(title='Animation', artist='Matplotlib')
writer = FFMpegWriter(fps=50, metadata=metadata, bitrate=200000) # change fps for different frame rates
fig = plt.figure(dpi=200)

# SAVE AS MP4 (will be saved in whatever directory you are working in)
fig, ax = plt.subplots()

with writer.saving(fig, "try2.mp4", dpi=200):
    for i in range(len(time_span)):

        ax.clear()

        ax.plot(r1_sol[:i,0],r1_sol[:i,1],color="blue", alpha=0.5) # plot the tail to the location of the planet
        ax.scatter(r1_sol[i,0],r1_sol[i,1],color="blue",marker="o",s=20, zorder=5) # plot the location of the planet
        
        ax.scatter(0, 0, color="orange",marker="*",s=50, zorder=5) # star
        
        #ax.set_xlim(-2e11, 2e11)
        #ax.set_ylim(-2e11, 2e11)
        ax.set_xlim(-1.5,1.5)
        ax.set_ylim(-1.5,1.5)

        
        plt.draw()
        plt.pause(0.01)
        writer.grab_frame()